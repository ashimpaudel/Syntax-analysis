Ashim Paudel
@02767602

			Syntax Analysis Programming Assignment

The URL of my Github project is:
https://github.com/ashimpaudel/Syntax-analysis

The following are the five most significant commits:
1.

https://github.com/ashimpaudel/Syntax-analysis/commit/fdac5d09184e18a15fa2d6af296f237e9b2a0208

Cobined 4.2 and 4.4.1

Date: Mar 22, 2017, 23 hours ago

2.

https://github.com/ashimpaudel/Syntax-analysis/commit/ea6ee15be9a12bd54278a48b288863148063ea1e

added expr() function inside main

Date: Mar 23, 2017, 23 hours ago

3.

https://github.com/ashimpaudel/Syntax-analysis/commit/db756d57c69ec811a6afbb82ae9f2abe71f44a0f

getting filename from command line arguement

Date: Mar 23, 2017, 4 hours ago

4.

https://github.com/ashimpaudel/Syntax-analysis/commit/cc5bda4c000a26c81f0a78d5dde86e3539742c5c

Reading multiple lines from input file

Date: Mar 23, 2017, 2 hours ago

5.
https://github.com/ashimpaudel/Syntax-analysis/commit/3c61e7d6027b9c86e5b5d6160653c2ea1a0839a0

Modified error function and resolved infinite loop

Date: Mar 23, 2017, 1 hours ago

